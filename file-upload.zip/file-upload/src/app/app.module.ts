import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatDialogModule} from '@angular/material/dialog';
import { HttpClientModule } from '@angular/common/http';
import { DialogUploadFileComponent } from './dialog-upload-file/dialog-upload-file.component';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatButtonModule} from '@angular/material/button';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {MatListModule} from '@angular/material/list';
import { UploadService } from './upload.service';

@NgModule({
  declarations: [
    AppComponent,
    DialogUploadFileComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MatDialogModule,
    HttpClientModule,
    MatSnackBarModule,
    MatButtonModule,
    MatProgressBarModule,
    MatListModule
  ],
  entryComponents: [DialogUploadFileComponent],
  providers: [UploadService],
  bootstrap: [AppComponent]
})
export class AppModule { }
