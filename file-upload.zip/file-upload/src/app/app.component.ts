import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { UploadService } from './upload.service';
import { DialogUploadFileComponent } from './dialog-upload-file/dialog-upload-file.component';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'file-upload';

  constructor(public dialog: MatDialog,
    public uploadService: UploadService,
    public snackBar: MatSnackBar) {
  }

  public openUploadDialog() {
    const dialogRef = this.dialog.open(DialogUploadFileComponent,
      {
        width: '50%',
        height: '50%',
        data: { id: 1 }
      });

    dialogRef.afterClosed().subscribe(result => {
      this.snackBar.open(
        'El fichero se subió correctamente', 'Cerrar', {
        duration: 3000,
        verticalPosition: 'top'
      });
    });
  }
}
